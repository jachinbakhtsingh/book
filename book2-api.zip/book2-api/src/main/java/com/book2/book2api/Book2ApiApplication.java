package com.book2.book2api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Book2ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Book2ApiApplication.class, args);
	}

}
