package com.book2.book2api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Book2ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
